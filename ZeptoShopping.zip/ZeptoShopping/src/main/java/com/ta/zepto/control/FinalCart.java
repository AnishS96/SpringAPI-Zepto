package com.ta.zepto.control;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.ta.zepto.dao.FinalCartDao;
import com.ta.zepto.model.ApiStatus;
import com.ta.zepto.model.CartItems;

@RestController
@RequestMapping("/finalCart")
public class FinalCart {
	
	@Autowired 
	FinalCartDao finalCart;
	Logger log = LogManager.getLogger("FinalCartController");
	
	@GetMapping(value="/cartdetails/{userId}")
	public ResponseEntity<ApiStatus> cartDetails(@PathVariable("userId") int userId) {
		
		try {
			log.info("cartDetails");
			List<CartItems>list=finalCart.finalCart(userId);
			if(list!=null) {
				log.info("List of items in cart");
				ApiStatus status = new ApiStatus( list, 200, "List of cart items");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.OK);
			}
			else {
				log.warn("List is null");
				ApiStatus status = new ApiStatus( null, 400, "Bad Data Request");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);
			}
		}
		catch (Exception e) {
		log.error("BAD request: "+e.getMessage());	
		ApiStatus status = new ApiStatus(false, 500, "Internal server Error");
		return new ResponseEntity<ApiStatus>(status,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	
	@DeleteMapping(value="/deleteCart/{userId}/{productId}")
	public ResponseEntity<ApiStatus> deleteCart(@PathVariable("userId")int userId,@PathVariable("productId")int productId) {
		
		try {
			log.info("Delete cart api");
			boolean deleteCart=finalCart.deleteCartItems(userId,productId);
			if(deleteCart==true) {
				log.info("cart items deleted");
				ApiStatus status = new ApiStatus( deleteCart, 400, "cart items deleted");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.OK);
			}
			else {
				log.warn("cart items not deleted");
				ApiStatus status = new ApiStatus( null, 400, "Bad Data Request");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);
			}
		}catch (Exception e) {
			log.error("BAD request: "+e.getMessage());	
			JSONPObject json=new JSONPObject("cart", false);
			ApiStatus status = new ApiStatus(false, 500, "Internal server Error");
			return new ResponseEntity<ApiStatus>(status,HttpStatus.INTERNAL_SERVER_ERROR);	
		}
	}
}
