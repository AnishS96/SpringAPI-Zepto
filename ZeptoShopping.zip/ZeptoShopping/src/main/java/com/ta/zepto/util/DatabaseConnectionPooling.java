package com.ta.zepto.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.logging.log4j.LogManager;
import org.springframework.context.annotation.Configuration;




@Configuration
public class DatabaseConnectionPooling {
	private String url = null; 
	String username = null;
	String password = null;
	String drivername = null;

	org.apache.logging.log4j.Logger log=LogManager.getLogger("ConnectionPool");
	private static BasicDataSource datasource = null;

	public BasicDataSource getConnectionDetails() {

		datasource = new BasicDataSource();
		try {
		FileInputStream file = new FileInputStream(
				"D:\\STS Workspace\\ZeptoShopping\\src\\main\\resources\\application.properties");

		Properties p = new Properties();
		p.load(file);

		url = p.getProperty("spring.datasource.url");
		username = p.getProperty("spring.datasource.username");
		password = p.getProperty("spring.datasource.password");
		drivername = p.getProperty("spring.datasource.driver-class-name");
		datasource.setUrl(url);
		datasource.setUsername(username);
		datasource.setPassword(password);
		datasource.setDriverClassName(drivername);

		datasource.setMinIdle(5);
		datasource.setMaxIdle(10);
		datasource.setMaxActive(25);

		return datasource;
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return datasource;
	}

	public Connection connection() throws SQLException {
		Connection connection = null;
		try {
		datasource =new DatabaseConnectionPooling().getConnectionDetails();
		connection = datasource.getConnection();
		} 
		catch(Exception e){
		e.printStackTrace();
		}
		log.info("database connection establised");
		return connection;
		} 
}









































































/*
public String propertyRead() throws IOException {

	FileInputStream file = new FileInputStream(
			"D:\\STS Workspace\\ZeptoShopping\\src\\main\\resources\\application.properties");

	Properties p = new Properties();
	p.load(file);

	url = p.getProperty("spring.datasource.url");
	username = p.getProperty("spring.datasource.username");
	password = p.getProperty("spring.datasource.password");
	drivername = p.getProperty("spring.datasource.driverClassName");
	return url + username + password + drivername;

}

*/