package com.ta.zepto.control;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.ta.zepto.dao.CustomerDao;
import com.ta.zepto.model.ApiStatus;
import com.ta.zepto.model.User;

@RestController
@RequestMapping("/zepto")
public class ZeptoUser {

	@Autowired
	CustomerDao database;
	Logger log = LogManager.getLogger("ZeptoUserController");

	@PostMapping(value = "/addUser", consumes = MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<ApiStatus> userDetails(@RequestBody User user) throws Exception {
		
		try {
			int pinTwo = user.getPin();
			if ((Integer.toString(pinTwo).length()) != 4) {
				// 850 - Invalid Length Of Data
				// 852 - Invalid Data
				log.error("Invalid length of data");
				ApiStatus status = new ApiStatus(null, 850, "Invalid length of data");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);
			} else {
				log.info("Mobile Number Validation is Success");
				User newUser = database.olduser(user);
				boolean addUser = database.InsertNewUser(newUser);
				if (addUser == false) {
					log.info("New User has not inserted");
					ApiStatus status = new ApiStatus(null, 400, "Customer Insertion failed");
					return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);

				} else {
					log.info("New User Inserted");
					ApiStatus status = new ApiStatus(user.getPhoneNumber(), 200, "Customer Details Inserted");
					return new ResponseEntity<ApiStatus>(status,HttpStatus.OK);


				}
			}
		} catch (Exception e) {
			log.error("SQL query exception" + e.getMessage());
			ApiStatus status = new ApiStatus(false, 500, "Internal server Error");
			return new ResponseEntity<ApiStatus>(status,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/oldUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiStatus> QueryDetails(@RequestBody User user) throws Exception {
		
		try {
			User oldUser = database.olduser(user);
			if (oldUser.getId() != user.getId()) {
				if (oldUser.getPin() != user.getPin()) {
					log.warn("Query has not inserted");
					ApiStatus status = new ApiStatus(null, 400, "Invalid Customer Details");
					return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);
				}
			} else {
				log.info("User details are verified");
				//JSONPObject json = new JSONPObject("OldUser ID", oldUser.getId());
				ApiStatus status = new ApiStatus( oldUser.getId(), 200, "Customer Details verified");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.OK);
			}

		} catch (Exception e) {
			log.error("database connection problem "+e.getMessage() );
			ApiStatus status = new ApiStatus(false, 500, "Internal server Error");
			return new ResponseEntity<ApiStatus>(status,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return null;
	}
}
