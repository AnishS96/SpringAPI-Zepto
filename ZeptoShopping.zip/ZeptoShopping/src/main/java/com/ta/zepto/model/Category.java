package com.ta.zepto.model;

import java.util.List;

public class Category {
	private int C_id;
	private String Category;
	
	public int getC_id() {
		return C_id;
	}

	@Override
	public String toString() {
		return "C_id=" + C_id + ", Category=" + Category ;
	}

	public Category(int c_id, String category) {
		super();
		C_id = c_id;
		Category = category;
	}

	public Category() {
		
	}

	public void setC_id(int c_id) {
		C_id = c_id;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

}
