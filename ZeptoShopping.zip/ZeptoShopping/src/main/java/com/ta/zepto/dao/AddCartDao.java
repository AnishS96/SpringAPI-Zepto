package com.ta.zepto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;

import com.ta.zepto.model.CartItems;
import com.ta.zepto.model.Products;
import com.ta.zepto.model.User;
import com.ta.zepto.util.DatabaseConnectionPooling;

@Configuration
public class AddCartDao {
	@Autowired
	DatabaseConnectionPooling database;
	org.apache.logging.log4j.Logger log = LogManager.getLogger("AddCartDAO");

	public boolean addtoCart(CartItems cart ) throws Exception {
		PreparedStatement statements = null;
		
		try {
			System.out.println(cart);
			String addProducts = "exec addToCart @UserID=?,@ProductID=?,@Quantity=?";
			Connection statement = database.connection();
			statements = statement.prepareStatement(addProducts);	
			statements.setInt(1, cart.getUserid());
			statements.setInt(2, cart.getProductid());
			statements.setInt(3, cart.getQuantity());
			statements.executeUpdate();
			if (statements.executeUpdate() > 0) {
				log.info("Cart details inserted");
				return true;
			} else {
				log.warn("Product not inserted");
				return false;
			}
		} catch (Exception e) {
			log.fatal("Exception Occured in SQL: " + e.getMessage());
			return false;
		}

	}
}
