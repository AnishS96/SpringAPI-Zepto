package com.ta.zepto.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.ta.zepto.model.ApiStatus;
import com.ta.zepto.model.User;
import com.ta.zepto.util.DatabaseConnectionPooling;

@Configuration
public class CustomerDao {
	@Autowired
	DatabaseConnectionPooling database;
	org.apache.logging.log4j.Logger log = LogManager.getLogger("CustomerDAO");

	public boolean InsertNewUser( User user) throws Exception {
		String query = "";
		try {
			query = "exec CustomerLogin @CustomerPin=?,@PhoneNumber=?";
			PreparedStatement statement = database.connection().prepareStatement(query);
			statement.setInt(1,user.getPin());
			statement.setInt(2, user.getPhoneNumber());
			if (statement.executeUpdate() > 0) {
				log.info("data inserted successfully");
				return true;
			} else {
				log.error("data insertion failed");
				return false;
			}
		} catch (SQLException e) {
			log.fatal("SQLException" + e.getLocalizedMessage());
			return false;
		} catch (Exception e) {
			log.fatal("Exception" + e.getLocalizedMessage());
			return false;
		}

	}

	public User olduser(User user) throws SQLException {
		String query = "Exec CustomerDetails @UserID=?,@CustomerPin=?;";
		try {
			PreparedStatement statement = database.connection().prepareStatement(query);
			statement.setInt(1, user.getId());
			statement.setInt(2, user.getPin());
			ResultSet rs=statement.executeQuery();
			User userr=null;
			while(rs.next()) {
				userr=new User(rs.getInt("UserID"),rs.getInt("CustomerPin"),rs.getInt("PhoneNumber"));
			}
		} catch (Exception e) {
			log.warn("sql Exception: " + e.getMessage());	
		}
		return user;
	}
}
