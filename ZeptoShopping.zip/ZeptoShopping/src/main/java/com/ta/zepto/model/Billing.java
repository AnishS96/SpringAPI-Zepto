package com.ta.zepto.model;

import java.util.List;

public class Billing {
	private List<BillItem>BillItems;
	private double totalAmount;
	private String message;
	private User user;

	private double getTotalAmount() {
		return totalAmount;
	}

	private void setTotalAmount(double totalAmount) {

		this.totalAmount = totalAmount;
	}

	private User getUser() {
		return user;
	}

	private void setUser(User user) {
		this.user = user;
	}

	private String getMessage() {
		return message;
	}

	private void setMessage(String message) {
		this.message = "your shopping details will be send via SMS";
	}

}
