package com.ta.zepto.model;

public class User {
	private int id;
	private int pin;
	private int phoneNumber;
	
	
	public User(int id, int pin, int phoneNumber) {
		super();
		this.id = id;
		this.pin = pin;
		this.phoneNumber = phoneNumber;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}

	}


