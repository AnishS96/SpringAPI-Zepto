package com.ta.zepto.model;

public class CartItems {
	private int id;
	public int Productid;
	private int quantity;
	public int userid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductid() {
		return Productid;
	}

	public void setProductid(int productid) {
		Productid = productid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public CartItems(int id, int productid, int quantity, int userid) {
		super();
		this.id = id;
		Productid = productid;
		this.quantity = quantity;
		this.userid = userid;
	}

}