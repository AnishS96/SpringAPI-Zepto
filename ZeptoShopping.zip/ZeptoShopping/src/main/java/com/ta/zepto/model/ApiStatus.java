package com.ta.zepto.model;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;

import com.fasterxml.jackson.databind.util.JSONPObject;

public class ApiStatus {
	private Object Response;
	private int HttpStatus;
	private String Message;

	
	public ApiStatus(Object response, int httpStatus, String message) {
		super();
		Response = response;
		HttpStatus = httpStatus;
		Message = message;
	}

	public int getHttpStatus() {
		return HttpStatus;
	}

	public void setHttpStatus(int httpStatus) {
		HttpStatus = httpStatus;
	}

	public Object getResponse() {
		return Response;
	}

	public void setResponse(Object response) {
		Response = response;
	}



	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

}
