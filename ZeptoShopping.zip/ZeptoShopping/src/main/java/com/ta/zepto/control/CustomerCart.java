package com.ta.zepto.control;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.ta.zepto.dao.AddCartDao;
import com.ta.zepto.dao.CustomerDao;
import com.ta.zepto.model.ApiStatus;
import com.ta.zepto.model.CartItems;
import com.ta.zepto.model.Products;

@RestController
@RequestMapping(value = "/addToCart")
public class CustomerCart {

	@Autowired
	AddCartDao database;
	Logger log = LogManager.getLogger("CustomerCartController");

	@PostMapping("/addCart")
	public ResponseEntity<ApiStatus> addcart(@RequestBody CartItems cart) throws Exception {
		
		try {

			boolean addtocart = database.addtoCart(cart);
			if (addtocart == true) {
				log.info("products added to Cart");
				ApiStatus status = new ApiStatus(addtocart, 200, "Products added to cart");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.OK);

			} else {
				log.warn("products not added");
				ApiStatus status = new ApiStatus(false, 400, "Bad data request");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			log.error("database connection problem "+e.getMessage());
			ApiStatus status = new ApiStatus(false, 500, "Internal server Error");
			return new ResponseEntity<ApiStatus>(status,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
