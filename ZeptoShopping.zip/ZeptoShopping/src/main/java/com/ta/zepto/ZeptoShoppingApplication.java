package com.ta.zepto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

@Component
@SpringBootApplication
public class ZeptoShoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZeptoShoppingApplication.class, args);
	}

}
