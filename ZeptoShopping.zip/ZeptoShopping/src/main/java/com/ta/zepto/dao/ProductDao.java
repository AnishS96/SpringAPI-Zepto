package com.ta.zepto.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.ta.zepto.model.Products;
import com.ta.zepto.util.DatabaseConnectionPooling;

@Configuration
public class ProductDao {

	@Autowired
	DatabaseConnectionPooling database;
	org.apache.logging.log4j.Logger log = LogManager.getLogger("ProductDAO");



public List<Products> getProduct(int Categoryid) throws Exception {
	try {
		String selectProducts = "exec Products @CategoryId=?";
		PreparedStatement statement=database.connection().prepareStatement(selectProducts);
		statement.setInt(1, Categoryid);
		ResultSet rs = statement.executeQuery();
		List<Products> list = new ArrayList<Products>();
		while (rs.next()) {
			list.add(new Products(rs.getInt("ProductID"), rs.getString("ProductName"), rs.getFloat("Price"),
					rs.getInt("CategoryId")));
		}
		return list;
	} catch (Exception e) {
		log.warn("Exception Occured in SQL: "+e.getMessage());
		return null ;
	}
}
}





































































































































/* 	public List<Products> getProducts(int Categoryid) throws Exception {
		try {
			String selectProducts = "select ProductID,ProductName,Price,CategoryId from ANISH_ZEPTOPRODUCTS  where CategoryId= "
					+ Categoryid;
			ResultSet rs = data.selectOperation(selectProducts);
			List<Products> list = new ArrayList<Products>();
			while (rs.next()) {
				list.add(new Products(rs.getInt("ProductID"), rs.getString("ProductName"), rs.getFloat("Price"),
						rs.getInt("CategoryId")));
			}
			return list;
		} catch (Exception e) {
			log.warn("Exception Occured in SQL: "+e.getMessage());
			return null ;
		}
	}
*/