package com.ta.zepto.model;

import java.util.List;

public class CustomerCart {
	private int cartid;
	private User user;
	private List<CartItems>CartItems;
	public int getCartid() {
		return cartid;
	}
	public void setCartid(int cartid) {
		this.cartid = cartid;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public List<CartItems> getCartItems() {
		return CartItems;
	}
	public void setCartItems(List<CartItems> cartItems) {
		CartItems = cartItems;
	}
	
	
}
