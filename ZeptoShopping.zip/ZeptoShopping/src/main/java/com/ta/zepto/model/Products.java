package com.ta.zepto.model;

public class Products {
	private int ProductID;
	private int quantity;
	private String ProductName;

	public Products(int productID, String productName, double price, int categoryId) {
		super();
		ProductID = productID;
		ProductName = productName;
		this.price = price;
		CategoryId = categoryId;
	}

	private double price;
	private int CategoryId;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getCategoryId() {
		return CategoryId;
	}

	public void setCategoryId(int categoryId) {
		CategoryId = categoryId;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public Products() {

	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		this.ProductID = productID;
	}

	private String getProducts() {
		return ProductName;
	}

	private void setProducts(String products) {
		this.ProductName = products;
	}

	private int getQuantity() {
		return quantity;
	}

	private void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
