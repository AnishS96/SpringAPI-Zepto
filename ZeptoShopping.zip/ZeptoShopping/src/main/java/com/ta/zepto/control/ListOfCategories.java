package com.ta.zepto.control;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.ta.zepto.dao.CategoryDao;
import com.ta.zepto.model.ApiStatus;
import com.ta.zepto.model.Category;

@RestController
@RequestMapping(value="/categoryTypes")
public class ListOfCategories {

	@Autowired
	CategoryDao database;
	Logger log = LogManager.getLogger("CategoryTypesController");

	@GetMapping("/listOfCategory")
	public ResponseEntity<ApiStatus> Category() throws Exception {
		
		try {
			List<Category> categories = database.Category();
			if (categories != null) {	
				log.info("List of Products");
				JSONPObject json=new JSONPObject("Catagories:", categories);
				ApiStatus status = new ApiStatus( categories, 200, "List of Category");
				return new ResponseEntity<ApiStatus>(status,HttpStatus.OK);
				} else {
					log.warn("List is null");
					ApiStatus status = new ApiStatus( null, 400, "Bad Data Request");
					return new ResponseEntity<ApiStatus>(status,HttpStatus.BAD_REQUEST);
				}
		} catch (Exception e) {
			log.error("database connection problem "+e.getMessage());
			ApiStatus status = new ApiStatus(false, 500, "Internal server Error");
			return new ResponseEntity<ApiStatus>(status,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
}
