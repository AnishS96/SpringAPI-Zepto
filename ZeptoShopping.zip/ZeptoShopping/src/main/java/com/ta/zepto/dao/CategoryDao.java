package com.ta.zepto.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.ta.zepto.model.Category;
import com.ta.zepto.util.DatabaseConnectionPooling;

@Configuration
public class CategoryDao {
	@Autowired
	DatabaseConnectionPooling database;
	org.apache.logging.log4j.Logger log = LogManager.getLogger("CatgoryDAO");


	public List<Category> Category() throws Exception {
		try {
			String productCategory = "Exec ProductCategories";
			PreparedStatement statement = database.connection().prepareStatement(productCategory);
			ResultSet rs = statement.executeQuery();
			List<Category> list = new ArrayList<Category>();
			while (rs.next()) {
				 list.add(new Category(rs.getInt("CategoryId"), rs.getString("Category")));
				}
			log.info("category shown ");
			
			return list;	
		} catch (Exception e) {
			log.warn("Exception Occured in SQL: " + e.getMessage());
		}
		return null;
		
	}
}