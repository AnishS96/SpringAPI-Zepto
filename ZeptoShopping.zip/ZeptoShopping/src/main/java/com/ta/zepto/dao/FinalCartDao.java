package com.ta.zepto.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.ta.zepto.model.CartItems;
import com.ta.zepto.model.Products;
import com.ta.zepto.model.User;
import com.ta.zepto.util.DatabaseConnectionPooling;

@Configuration
public class FinalCartDao {
	@Autowired
	DatabaseConnectionPooling database;
	org.apache.logging.log4j.Logger log = LogManager.getLogger("FinalCartDao");

	public List<CartItems> finalCart(int userId) {
		PreparedStatement statement = null;
		try {
			String query = "exec finalCart @UserID=?";
			statement = database.connection().prepareStatement(query);
			statement.setInt(1, userId);
			ResultSet rs = statement.executeQuery();
			List<CartItems> list = new ArrayList<CartItems>();
			while (rs.next()) {
				list.add(new CartItems(rs.getInt("ID"),rs.getInt("UserID"),rs.getInt("ProductID"),rs.getInt("Quantity")));
				log.info("cart items selected");
			}
			return list;
		} catch (Exception e) {
			log.fatal("SQL Exception: " + e.getMessage());
			return null;
		}

	}

	
	
	
	public boolean deleteCartItems(int userId, int productId) {
		log.info("remove the cart items");
		PreparedStatement statement = null;
		try {
			String query = "exec deleteCart @UserID=?,@ProductID=?";
			statement = database.connection().prepareStatement(query);
			statement.setInt(1, userId);
			statement.setInt(2, productId);
			
			if(statement.executeUpdate()>0) {
				log.info("query executed and product deleted");
				return true;
			}
			else {
				log.warn("query executed and product is not deleted");
				return false;
			}
		}catch (Exception e) {
			log.error("SQL Exception : " + e.getLocalizedMessage());
			return false;
		}
	}
}
